
import * as Li9za2lrby5tanM from './skiko.mjs';
import * as QGpzLWpvZGEvY29yZQ from '@js-joda/core';
import * as d2FzbTpqcy1zdHJpbmc from './a2uiCatalogRenderer.js-builtins.mjs';

const wasmJsTag = WebAssembly.JSTag;
const wasmTag = wasmJsTag ?? new WebAssembly.Tag({ parameters: ['externref'] });

// Placed here to give access to it from externals (js_code)
let wasmExports;

if (typeof process !== 'undefined' && process.release.name === 'node') {
    function doNotUseRequire() {
        throw new Error("Do not use top-level require. Prefer to use JS import or define your own require instead. Read more: https://kotl.in/r9txlt")
    }

    var require = new Proxy((function() {}), {
        apply(target, thisArg, argumentsList) {
            if (globalThis.require != null) {
                return globalThis.require.apply(thisArg, argumentsList);
            } else {
                doNotUseRequire();
            }
        },
        get(target, prop, receiver) {
            if (globalThis.require != null) {
                return Reflect.get(globalThis.require, prop);
            } else {
                doNotUseRequire();
            }
        },
    });
}

export function setWasmExports(exports) {
    wasmExports = exports;
}

const _ref_Li9za2lrby5tanM_ = Li9za2lrby5tanM;
const _ref_Li9za2lrby5tanM_c2tpa29BcGk = Li9za2lrby5tanM.skikoApi;
const _ref_QGpzLWpvZGEvY29yZQ_ = QGpzLWpvZGEvY29yZQ;

const cachedJsObjects = new WeakMap();
function getCachedJsObject(ref, ifNotCached) {
    if (typeof ref !== 'object' && typeof ref !== 'function') return ifNotCached;
    const cached = cachedJsObjects.get(ref);
    if (cached !== void 0) return cached;
    cachedJsObjects.set(ref, ifNotCached);
    return ifNotCached;
}

const js_code = {
    'kotlin.createJsError' : (message, cause) => new Error(message, { cause }),
    'kotlin.wasm.internal.jsThrow' : wasmTag === wasmJsTag ? (e) => { throw e; } : () => {},
    'kotlin.wasm.internal.getJsEmptyString' : () => '',
    'kotlin.wasm.internal.externrefToInt' : (ref) => Number(ref),
    'kotlin.wasm.internal.intToExternref' : (x) => x,
    'kotlin.wasm.internal.externrefToDouble' : (ref) => Number(ref),
    'kotlin.wasm.internal.externrefToString' : (ref) => String(ref),
    'kotlin.wasm.internal.externrefEquals' : (lhs, rhs) => lhs === rhs,
    'kotlin.wasm.internal.externrefHashCode' : 
    (() => {
    const dataView = new DataView(new ArrayBuffer(8));
    function numberHashCode(obj) {
        if ((obj | 0) === obj) {
            return obj | 0;
        } else {
            dataView.setFloat64(0, obj, true);
            return (dataView.getInt32(0, true) * 31 | 0) + dataView.getInt32(4, true) | 0;
        }
    }

    const hashCodes = new WeakMap();
    function getObjectHashCode(obj) {
        const res = hashCodes.get(obj);
        if (res === undefined) {
            const POW_2_32 = 4294967296;
            const hash = (Math.random() * POW_2_32) | 0;
            hashCodes.set(obj, hash);
            return hash;
        }
        return res;
    }

    function getStringHashCode(str) {
        var hash = 0;
        for (var i = 0; i < str.length; i++) {
            var code  = str.charCodeAt(i);
            hash  = (hash * 31 + code) | 0;
        }
        return hash;
    }

    return (obj) => {
        if (obj == null) {
            return 0;
        }
        switch (typeof obj) {
            case "object":
            case "function":
                return getObjectHashCode(obj);
            case "number":
                return numberHashCode(obj);
            case "boolean":
                return obj ? 1231 : 1237;
            default:
                return getStringHashCode(String(obj)); 
        }
    }
    })(),
    'kotlin.wasm.internal.isNullish' : (ref) => ref == null,
    'kotlin.wasm.internal.getJsTrue' : () => true,
    'kotlin.wasm.internal.getJsFalse' : () => false,
    'kotlin.wasm.internal.kotlinUIntToJsNumberUnsafe' : (x) => x >>> 0,
    'kotlin.wasm.internal.kotlinULongToJsBigIntUnsafe' : (x) => x & 0xFFFFFFFFFFFFFFFFn,
    'kotlin.wasm.internal.newJsArray' : () => [],
    'kotlin.wasm.internal.jsArrayPush' : (array, element) => { array.push(element); },
    'kotlin.wasm.internal.getCachedJsObject_$external_fun' : (p0, p1) => getCachedJsObject(p0, p1),
    'kotlin.wasm.internal.utoa32_$external_fun' : (p0) => String(p0),
    'kotlin.wasm.internal.utoa64_$external_fun' : (p0) => String(p0),
    'kotlin.wasm.internal.itoa32_$external_fun' : (p0) => String(p0),
    'kotlin.wasm.internal.itoa64_$external_fun' : (p0) => String(p0),
    'kotlin.js.jsCatch' : (f) => { 
        let result = null;
        try { 
            f();
        } catch (e) {
           result = e;
        }
        return result;
         },
    'kotlin.js.__convertKotlinClosureToJsClosure_0' : (f, trampoline) => getCachedJsObject(f, () => trampoline(f, )),
    'kotlin.js.jsThrow' : (e) => { throw e; },
    'kotlin.io.printlnImpl' : (message) => console.log(message),
    'kotlin.js.jsArrayGet' : (array, index) => array[index],
    'kotlin.js.jsArraySet' : (array, index, value) => { array[index] = value },
    'kotlin.js.JsArray_$external_fun' : () => new Array(),
    'kotlin.js.length_$external_prop_getter' : (_this) => _this.length,
    'kotlin.js.stackPlaceHolder_js_code' : () => (''),
    'kotlin.js.message_$external_prop_getter' : (_this) => _this.message,
    'kotlin.js.name_$external_prop_setter' : (_this, v) => _this.name = v,
    'kotlin.js.stack_$external_prop_getter' : (_this) => _this.stack,
    'kotlin.js.kotlinException_$external_prop_getter' : (_this) => _this.kotlinException,
    'kotlin.js.kotlinException_$external_prop_setter' : (_this, v) => _this.kotlinException = v,
    'kotlin.js.JsError_$external_class_instanceof' : (x) => x instanceof Error,
    'kotlin.js.JsString_$external_class_instanceof' : (x) => typeof x === 'string',
    'kotlin.js.JsString_$external_class_get' : () => JsString,
    'kotlin.js.then_$external_fun' : (_this, p0) => _this.then(p0),
    'kotlin.js.__convertKotlinClosureToJsClosure_1' : (f, trampoline) => getCachedJsObject(f, (p0) => trampoline(f, p0)),
    'kotlin.js.then_$external_fun_1' : (_this, p0, p1) => _this.then(p0, p1),
    'kotlin.js.catch_$external_fun' : (_this, p0) => _this.catch(p0),
    'kotlin.random.initialSeed' : () => ((Math.random() * Math.pow(2, 32)) | 0),
    'kotlin.wasm.internal.getJsClassName' : (jsKlass) => jsKlass.name,
    'kotlin.wasm.internal.instanceOf' : (ref, jsKlass) => ref instanceof jsKlass,
    'kotlin.wasm.internal.getConstructor' : (obj) => obj.constructor,
    'kotlin.time.Date_$external_fun' : () => new Date(),
    'kotlin.time.getTime_$external_fun' : (_this, ) => _this.getTime(),
    'kotlin.time.tryGetPerformance' : () => typeof globalThis !== 'undefined' && typeof globalThis.performance !== 'undefined' ? globalThis.performance : null,
    'kotlin.time.getPerformanceNow' : (performance) => performance.now(),
    'kotlin.time.dateNow' : () => Date.now(),
    'kotlinx.coroutines.tryGetProcess' : () => (typeof(process) !== 'undefined' && typeof(process.nextTick) === 'function') ? process : null,
    'kotlinx.coroutines.tryGetWindow' : () => (typeof(window) !== 'undefined' && window != null && typeof(window.addEventListener) === 'function') ? window : null,
    'kotlinx.coroutines.nextTick_$external_fun' : (_this, p0) => _this.nextTick(p0),
    'kotlinx.coroutines.error_$external_fun' : (_this, p0) => _this.error(p0),
    'kotlinx.coroutines.console_$external_prop_getter' : () => console,
    'kotlinx.coroutines.createScheduleMessagePoster' : (process) => () => Promise.resolve(0).then(process),
    'kotlinx.coroutines.__callJsClosure_(()->Unit)' : (f, ) => f(),
    'kotlinx.coroutines.createRescheduleMessagePoster' : (window) => () => window.postMessage('dispatchCoroutine', '*'),
    'kotlinx.coroutines.subscribeToWindowMessages' : (window, process) => {
        const handler = (event) => {
            if (event.source == window && event.data == 'dispatchCoroutine') {
                event.stopPropagation();
                process();
            }
        }
        window.addEventListener('message', handler, true);
    },
    'kotlinx.coroutines.setTimeout' : (window, handler, timeout) => window.setTimeout(handler, timeout),
    'kotlinx.coroutines.clearTimeout' : (handle) => { if (typeof clearTimeout !== 'undefined') clearTimeout(handle); },
    'kotlinx.coroutines.clearTimeout_$external_fun' : (_this, p0) => _this.clearTimeout(p0),
    'kotlinx.coroutines.setTimeout_$external_fun' : (p0, p1) => setTimeout(p0, p1),
    'org.khronos.webgl.getMethodImplForInt8Array' : (obj, index) => obj[index],
    'org.khronos.webgl.Int8Array_$external_fun' : (p0, p1, p2, isDefault0, isDefault1) => new Int8Array(p0, isDefault0 ? undefined : p1, isDefault1 ? undefined : p2, ),
    'org.khronos.webgl.length_$external_prop_getter' : (_this) => _this.length,
    'org.w3c.dom.clipboard.clipboardData_$external_prop_getter' : (_this) => _this.clipboardData,
    'org.w3c.dom.clipboard.ClipboardEvent_$external_class_instanceof' : (x) => x instanceof ClipboardEvent,
    'org.w3c.dom.css.cursor_$external_prop_setter' : (_this, v) => _this.cursor = v,
    'org.w3c.dom.css.display_$external_prop_setter' : (_this, v) => _this.display = v,
    'org.w3c.dom.css.fontSize_$external_prop_getter' : (_this) => _this.fontSize,
    'org.w3c.dom.css.fontSize_$external_prop_setter' : (_this, v) => _this.fontSize = v,
    'org.w3c.dom.css.height_$external_prop_setter' : (_this, v) => _this.height = v,
    'org.w3c.dom.css.left_$external_prop_setter' : (_this, v) => _this.left = v,
    'org.w3c.dom.css.opacity_$external_prop_setter' : (_this, v) => _this.opacity = v,
    'org.w3c.dom.css.outline_$external_prop_setter' : (_this, v) => _this.outline = v,
    'org.w3c.dom.css.position_$external_prop_setter' : (_this, v) => _this.position = v,
    'org.w3c.dom.css.top_$external_prop_setter' : (_this, v) => _this.top = v,
    'org.w3c.dom.css.whiteSpace_$external_prop_setter' : (_this, v) => _this.whiteSpace = v,
    'org.w3c.dom.css.width_$external_prop_setter' : (_this, v) => _this.width = v,
    'org.w3c.dom.css.setProperty_$external_fun' : (_this, p0, p1, p2, isDefault0) => _this.setProperty(p0, p1, isDefault0 ? undefined : p2, ),
    'org.w3c.dom.css.style_$external_prop_getter' : (_this) => _this.style,
    'org.w3c.dom.events.type_$external_prop_getter' : (_this) => _this.type,
    'org.w3c.dom.events.target_$external_prop_getter' : (_this) => _this.target,
    'org.w3c.dom.events.cancelable_$external_prop_getter' : (_this) => _this.cancelable,
    'org.w3c.dom.events.timeStamp_$external_prop_getter' : (_this) => _this.timeStamp,
    'org.w3c.dom.events.preventDefault_$external_fun' : (_this, ) => _this.preventDefault(),
    'org.w3c.dom.events.Event_$external_class_instanceof' : (x) => x instanceof Event,
    'org.w3c.dom.events.key_$external_prop_getter' : (_this) => _this.key,
    'org.w3c.dom.events.code_$external_prop_getter' : (_this) => _this.code,
    'org.w3c.dom.events.ctrlKey_$external_prop_getter' : (_this) => _this.ctrlKey,
    'org.w3c.dom.events.shiftKey_$external_prop_getter' : (_this) => _this.shiftKey,
    'org.w3c.dom.events.altKey_$external_prop_getter' : (_this) => _this.altKey,
    'org.w3c.dom.events.metaKey_$external_prop_getter' : (_this) => _this.metaKey,
    'org.w3c.dom.events.isComposing_$external_prop_getter' : (_this) => _this.isComposing,
    'org.w3c.dom.events.keyCode_$external_prop_getter' : (_this) => _this.keyCode,
    'org.w3c.dom.events.KeyboardEvent_$external_class_instanceof' : (x) => x instanceof KeyboardEvent,
    'org.w3c.dom.events.KeyboardEvent_$external_class_get' : () => KeyboardEvent,
    'org.w3c.dom.events.deltaX_$external_prop_getter' : (_this) => _this.deltaX,
    'org.w3c.dom.events.deltaY_$external_prop_getter' : (_this) => _this.deltaY,
    'org.w3c.dom.events.deltaMode_$external_prop_getter' : (_this) => _this.deltaMode,
    'org.w3c.dom.events.DOM_DELTA_PIXEL_$external_prop_getter' : (_this) => _this.DOM_DELTA_PIXEL,
    'org.w3c.dom.events.DOM_DELTA_LINE_$external_prop_getter' : (_this) => _this.DOM_DELTA_LINE,
    'org.w3c.dom.events.DOM_DELTA_PAGE_$external_prop_getter' : (_this) => _this.DOM_DELTA_PAGE,
    'org.w3c.dom.events.Companion_$external_object_getInstance' : () => WheelEvent,
    'org.w3c.dom.events.WheelEvent_$external_class_instanceof' : (x) => x instanceof WheelEvent,
    'org.w3c.dom.events.addEventListener_$external_fun' : (_this, p0, p1, p2) => _this.addEventListener(p0, p1, p2),
    'org.w3c.dom.events.addEventListener_$external_fun_1' : (_this, p0, p1) => _this.addEventListener(p0, p1),
    'org.w3c.dom.events.addEventListener_$external_fun_2' : (_this, p0, p1) => _this.addEventListener(p0, p1),
    'org.w3c.dom.events.removeEventListener_$external_fun' : (_this, p0, p1) => _this.removeEventListener(p0, p1),
    'org.w3c.dom.events.removeEventListener_$external_fun_1' : (_this, p0, p1) => _this.removeEventListener(p0, p1),
    'org.w3c.dom.events.ctrlKey_$external_prop_getter_1' : (_this) => _this.ctrlKey,
    'org.w3c.dom.events.shiftKey_$external_prop_getter_1' : (_this) => _this.shiftKey,
    'org.w3c.dom.events.altKey_$external_prop_getter_1' : (_this) => _this.altKey,
    'org.w3c.dom.events.metaKey_$external_prop_getter_1' : (_this) => _this.metaKey,
    'org.w3c.dom.events.button_$external_prop_getter' : (_this) => _this.button,
    'org.w3c.dom.events.buttons_$external_prop_getter' : (_this) => _this.buttons,
    'org.w3c.dom.events.offsetX_$external_prop_getter' : (_this) => _this.offsetX,
    'org.w3c.dom.events.offsetY_$external_prop_getter' : (_this) => _this.offsetY,
    'org.w3c.dom.events.isComposing_$external_prop_getter_1' : (_this) => _this.isComposing,
    'org.w3c.dom.events.InputEvent_$external_class_instanceof' : (x) => x instanceof InputEvent,
    'org.w3c.dom.events.InputEvent_$external_class_get' : () => InputEvent,
    'org.w3c.dom.events.data_$external_prop_getter' : (_this) => _this.data,
    'org.w3c.dom.events.CompositionEvent_$external_class_instanceof' : (x) => x instanceof CompositionEvent,
    'org.w3c.dom.events.CompositionEvent_$external_class_get' : () => CompositionEvent,
    'org.w3c.dom.ShadowRootInit' : (mode) => ({ mode: mode }),
    'org.w3c.dom.navigator_$external_prop_getter' : (_this) => _this.navigator,
    'org.w3c.dom.innerWidth_$external_prop_getter' : (_this) => _this.innerWidth,
    'org.w3c.dom.innerHeight_$external_prop_getter' : (_this) => _this.innerHeight,
    'org.w3c.dom.devicePixelRatio_$external_prop_getter' : (_this) => _this.devicePixelRatio,
    'org.w3c.dom.requestAnimationFrame_$external_fun' : (_this, p0) => _this.requestAnimationFrame(p0),
    'org.w3c.dom.matchMedia_$external_fun' : (_this, p0) => _this.matchMedia(p0),
    'org.w3c.dom.getComputedStyle_$external_fun' : (_this, p0, p1, isDefault0) => _this.getComputedStyle(p0, isDefault0 ? undefined : p1, ),
    'org.w3c.dom.tabIndex_$external_prop_setter' : (_this, v) => _this.tabIndex = v,
    'org.w3c.dom.innerText_$external_prop_getter' : (_this) => _this.innerText,
    'org.w3c.dom.innerText_$external_prop_setter' : (_this, v) => _this.innerText = v,
    'org.w3c.dom.click_$external_fun' : (_this, ) => _this.click(),
    'org.w3c.dom.focus_$external_fun' : (_this, ) => _this.focus(),
    'org.w3c.dom.blur_$external_fun' : (_this, ) => _this.blur(),
    'org.w3c.dom.HTMLElement_$external_class_instanceof' : (x) => x instanceof HTMLElement,
    'org.w3c.dom.HTMLElement_$external_class_get' : () => HTMLElement,
    'org.w3c.dom.readyState_$external_prop_getter' : (_this) => _this.readyState,
    'org.w3c.dom.body_$external_prop_getter' : (_this) => _this.body,
    'org.w3c.dom.activeElement_$external_prop_getter' : (_this) => _this.activeElement,
    'org.w3c.dom.createElement_$external_fun' : (_this, p0, p1, isDefault0) => _this.createElement(p0, isDefault0 ? undefined : p1, ),
    'org.w3c.dom.createTextNode_$external_fun' : (_this, p0) => _this.createTextNode(p0),
    'org.w3c.dom.hasFocus_$external_fun' : (_this, ) => _this.hasFocus(),
    'org.w3c.dom.getElementById_$external_fun' : (_this, p0) => _this.getElementById(p0),
    'org.w3c.dom.id_$external_prop_setter' : (_this, v) => _this.id = v,
    'org.w3c.dom.classList_$external_prop_getter' : (_this) => _this.classList,
    'org.w3c.dom.shadowRoot_$external_prop_getter' : (_this) => _this.shadowRoot,
    'org.w3c.dom.clientWidth_$external_prop_getter' : (_this) => _this.clientWidth,
    'org.w3c.dom.clientHeight_$external_prop_getter' : (_this) => _this.clientHeight,
    'org.w3c.dom.setAttribute_$external_fun' : (_this, p0, p1) => _this.setAttribute(p0, p1),
    'org.w3c.dom.removeAttribute_$external_fun' : (_this, p0) => _this.removeAttribute(p0),
    'org.w3c.dom.hasAttribute_$external_fun' : (_this, p0) => _this.hasAttribute(p0),
    'org.w3c.dom.attachShadow_$external_fun' : (_this, p0) => _this.attachShadow(p0),
    'org.w3c.dom.getBoundingClientRect_$external_fun' : (_this, ) => _this.getBoundingClientRect(),
    'org.w3c.dom.isConnected_$external_prop_getter' : (_this) => _this.isConnected,
    'org.w3c.dom.parentElement_$external_prop_getter' : (_this) => _this.parentElement,
    'org.w3c.dom.firstChild_$external_prop_getter' : (_this) => _this.firstChild,
    'org.w3c.dom.nextSibling_$external_prop_getter' : (_this) => _this.nextSibling,
    'org.w3c.dom.textContent_$external_prop_getter' : (_this) => _this.textContent,
    'org.w3c.dom.textContent_$external_prop_setter' : (_this, v) => _this.textContent = v,
    'org.w3c.dom.insertBefore_$external_fun' : (_this, p0, p1) => _this.insertBefore(p0, p1),
    'org.w3c.dom.appendChild_$external_fun' : (_this, p0) => _this.appendChild(p0),
    'org.w3c.dom.removeChild_$external_fun' : (_this, p0) => _this.removeChild(p0),
    'org.w3c.dom.dropEffect_$external_prop_setter' : (_this, v) => _this.dropEffect = v,
    'org.w3c.dom.setDragImage_$external_fun' : (_this, p0, p1, p2) => _this.setDragImage(p0, p1, p2),
    'org.w3c.dom.getData_$external_fun' : (_this, p0) => _this.getData(p0),
    'org.w3c.dom.setData_$external_fun' : (_this, p0, p1) => _this.setData(p0, p1),
    'org.w3c.dom.width_$external_prop_getter' : (_this) => _this.width,
    'org.w3c.dom.width_$external_prop_setter' : (_this, v) => _this.width = v,
    'org.w3c.dom.height_$external_prop_getter' : (_this) => _this.height,
    'org.w3c.dom.height_$external_prop_setter' : (_this, v) => _this.height = v,
    'org.w3c.dom.HTMLCanvasElement_$external_class_instanceof' : (x) => x instanceof HTMLCanvasElement,
    'org.w3c.dom.HTMLCanvasElement_$external_class_get' : () => HTMLCanvasElement,
    'org.w3c.dom.HTMLDivElement_$external_class_instanceof' : (x) => x instanceof HTMLDivElement,
    'org.w3c.dom.HTMLDivElement_$external_class_get' : () => HTMLDivElement,
    'org.w3c.dom.HTMLTextAreaElement_$external_class_instanceof' : (x) => x instanceof HTMLTextAreaElement,
    'org.w3c.dom.HTMLTextAreaElement_$external_class_get' : () => HTMLTextAreaElement,
    'org.w3c.dom.item_$external_fun' : (_this, p0) => _this.item(p0),
    'org.w3c.dom.dataTransfer_$external_prop_getter' : (_this) => _this.dataTransfer,
    'org.w3c.dom.DragEvent_$external_class_instanceof' : (x) => x instanceof DragEvent,
    'org.w3c.dom.DragEvent_$external_class_get' : () => DragEvent,
    'org.w3c.dom.matches_$external_prop_getter' : (_this) => _this.matches,
    'org.w3c.dom.addListener_$external_fun' : (_this, p0) => _this.addListener(p0),
    'org.w3c.dom.removeListener_$external_fun' : (_this, p0) => _this.removeListener(p0),
    'org.w3c.dom.MediaQueryList_$external_class_instanceof' : (x) => x instanceof MediaQueryList,
    'org.w3c.dom.MediaQueryList_$external_class_get' : () => MediaQueryList,
    'org.w3c.dom.matches_$external_prop_getter_1' : (_this) => _this.matches,
    'org.w3c.dom.MediaQueryListEvent_$external_class_instanceof' : (x) => x instanceof MediaQueryListEvent,
    'org.w3c.dom.MediaQueryListEvent_$external_class_get' : () => MediaQueryListEvent,
    'org.w3c.dom.add_$external_fun' : (_this, p0) => _this.add(...p0),
    'org.w3c.dom.userAgent_$external_prop_getter' : (_this) => _this.userAgent,
    'org.w3c.dom.language_$external_prop_getter' : (_this) => _this.language,
    'org.w3c.dom.fetch_$external_fun' : (_this, p0, p1, isDefault0) => _this.fetch(p0, isDefault0 ? undefined : p1, ),
    'org.w3c.dom.children_$external_prop_getter' : (_this) => _this.children,
    'org.w3c.dom.firstElementChild_$external_prop_getter' : (_this) => _this.firstElementChild,
    'org.w3c.dom.lastElementChild_$external_prop_getter' : (_this) => _this.lastElementChild,
    'org.w3c.dom.Companion_$external_object_getInstance' : () => ({}),
    'org.w3c.dom.top_$external_prop_getter' : (_this) => _this.top,
    'org.w3c.dom.right_$external_prop_getter' : (_this) => _this.right,
    'org.w3c.dom.bottom_$external_prop_getter' : (_this) => _this.bottom,
    'org.w3c.dom.left_$external_prop_getter' : (_this) => _this.left,
    'org.w3c.dom.nextElementSibling_$external_prop_getter' : (_this) => _this.nextElementSibling,
    'org.w3c.dom.remove_$external_fun' : (_this, ) => _this.remove(),
    'org.w3c.dom.Companion_$external_object_getInstance_1' : () => ({}),
    'org.w3c.dom.pointerevents.pointerId_$external_prop_getter' : (_this) => _this.pointerId,
    'org.w3c.dom.pointerevents.pressure_$external_prop_getter' : (_this) => _this.pressure,
    'org.w3c.fetch.arrayBuffer_$external_fun' : (_this, ) => _this.arrayBuffer(),
    'org.w3c.performance.now_$external_fun' : (_this, ) => _this.now(),
    'org.w3c.performance.performance_$external_prop_getter' : (_this) => _this.performance,
    'kotlinx.browser.window_$external_prop_getter' : () => window,
    'kotlinx.browser.document_$external_prop_getter' : () => document,
    'org.w3c.dom.length_$external_prop_getter' : (_this) => _this.length,
    'androidx.compose.runtime.internal.weakMap_js_code' : () => (new WeakMap()),
    'androidx.compose.runtime.internal.set_$external_fun' : (_this, p0, p1) => _this.set(p0, p1),
    'androidx.compose.runtime.internal.get_$external_fun' : (_this, p0) => _this.get(p0),
    'androidx.compose.runtime.internal.WeakRef_$external_fun' : (p0) => new WeakRef(p0),
    'androidx.compose.runtime.internal.deref_$external_fun' : (_this, ) => _this.deref(),
    'org.jetbrains.skiko.GL_$external_prop_getter' : () => _ref_Li9za2lrby5tanM_.GL,
    'org.jetbrains.skia.impl.FinalizationRegistry_$external_fun' : (p0) => new FinalizationRegistry(p0),
    'org.jetbrains.skia.impl.register_$external_fun' : (_this, p0, p1, p2) => _this.register(p0, p1, p2),
    'org.jetbrains.skia.impl.unregister_$external_fun' : (_this, p0) => _this.unregister(p0),
    'org.jetbrains.skia.impl._releaseLocalCallbackScope_$external_fun' : () => _ref_Li9za2lrby5tanM_c2tpa29BcGk._releaseLocalCallbackScope(),
    'org.jetbrains.skiko.wasm.createDefaultContextAttributes' : () => {
        return {
            alpha: 1,
            depth: 1,
            stencil: 8,
            antialias: 0,
            premultipliedAlpha: 1,
            preserveDrawingBuffer: 0,
            preferLowPowerToHighPerformance: 0,
            failIfMajorPerformanceCaveat: 0,
            enableExtensionsByDefault: 1,
            explicitSwapControl: 0,
            renderViaOffscreenBackBuffer: 0,
            majorVersion: 2,
        }
    }
    ,
    'org.jetbrains.skiko.wasm.awaitSkiko_$external_prop_getter' : () => _ref_Li9za2lrby5tanM_.awaitSkiko,
    'org.jetbrains.skiko.currentNanoTimeWindowPerformance' : () => window.performance.now() * 1000000,
    'org.jetbrains.skiko.windowRequestAnimationFrame' : (callback) => window.requestAnimationFrame(callback),
    'org.jetbrains.skiko.createContext_$external_fun' : (_this, p0, p1) => _this.createContext(p0, p1),
    'org.jetbrains.skiko.makeContextCurrent_$external_fun' : (_this, p0) => _this.makeContextCurrent(p0),
    'org.jetbrains.skiko.getNavigatorInfo' : () => navigator.userAgentData ? navigator.userAgentData.platform : navigator.platform,
    'org.jetbrains.skiko.defaultFetchInit_js_code' : () => ({}),
    'org.jetbrains.skiko.jsCatch' : function (f) { try { f(); } catch (e) { return e;}; return null; },
    'org.jetbrains.skiko.jsThrow' : (e) => { throw e; },
    'org.jetbrains.skiko.wasm.patchWebGlContext' : (canvas) => {
        if (!canvas.getContext.webGlContextPatched) {
            var oldGetContext = canvas.getContext;
            canvas.getContext = function() {
                var gl = oldGetContext.apply(this, arguments);
                if (gl && !gl.webGlContextPatched) {
                    var oldGetSupportedExtensions = gl.getSupportedExtensions;
                    if (typeof oldGetSupportedExtensions === 'function') {
                        gl.getSupportedExtensions = function() {
                            var exts = oldGetSupportedExtensions.apply(this, arguments);
                            if (exts && exts.filter) {
                                return exts.filter(function(name) {
                                    return name !== 'WEBGL_debug_renderer_info' && name !== 'WEBGL_polygon_mode';
                                });
                            }
                            return exts;
                        };
                    }
                    var oldGetExtension = gl.getExtension;
                    if (typeof oldGetExtension === 'function') {
                        gl.getExtension = function(name) {
                            if (name === 'WEBGL_debug_renderer_info' || name === 'WEBGL_polygon_mode') {
                                return null;
                            }
                            return oldGetExtension.apply(this, arguments);
                        };
                    }
                    var oldGetParameter = gl.getParameter;
                    if (typeof oldGetParameter === 'function') {
                        gl.getParameter = function(pname) {
                            // 0x9245 = UNMASKED_VENDOR_WEBGL, 0x9246 = UNMASKED_RENDERER_WEBGL;
                            // both belong to WEBGL_debug_renderer_info, so hide them to avoid the INVALID_ENUM warning
                            if (pname === 0x9245 || pname === 0x9246) {
                                return "";
                            }
                            // 0x0C02 = READ_BUFFER;
                            // hide to avoid "The READ_BUFFER attachment is multisampled" warning in Firefox
                            if (pname === 0x0C02) {
                                var fbo = oldGetParameter.apply(this, [0x8CAA]); // 0x8CAA = READ_FRAMEBUFFER_BINDING
                                return fbo ? 0x8CE0 : 0x0405; // 0x8CE0 = COLOR_ATTACHMENT0, 0x0405 = BACK
                            }
                            return oldGetParameter.apply(this, arguments);
                        };
                    }
                    gl.webGlContextPatched = true;
                }
                return gl;
            };
            canvas.getContext.webGlContextPatched = true;
        }
    },
    'androidx.lifecycle.WeakRef_$external_fun' : (p0) => new WeakRef(p0),
    'androidx.lifecycle.deref_$external_fun' : (_this, ) => _this.deref(),
    'androidx.compose.ui.text.WeakRef_$external_fun' : (p0) => new WeakRef(p0),
    'androidx.compose.ui.text.deref_$external_fun' : (_this, ) => _this.deref(),
    'androidx.compose.ui.text.intl.parseLanguageTagToIntlLocale' : (languageTag) => new Intl.Locale(languageTag),
    'androidx.compose.ui.text.intl.getUserPreferredLanguagesAsArray' : () => window.navigator.languages,
    'androidx.compose.ui.text.intl._language_$external_prop_getter' : (_this) => _this.language,
    'androidx.compose.ui.text.intl._region_$external_prop_getter' : (_this) => _this.region,
    'androidx.compose.ui.text.intl._baseName_$external_prop_getter' : (_this) => _this.baseName,
    'androidx.compose.ui.text.FinalizationRegistry_$external_fun' : (p0) => new FinalizationRegistry(p0),
    'androidx.compose.ui.text.register_$external_fun' : (_this, p0, p1) => _this.register(p0, p1),
    'androidx.compose.ui.text.WeakRef_$external_fun_1' : (p0) => new WeakRef(p0),
    'androidx.compose.ui.text.deref_$external_fun_1' : (_this, ) => _this.deref(),
    'androidx.compose.ui.internal.weakMap_js_code' : () => (new WeakMap()),
    'androidx.compose.ui.internal.set_$external_fun' : (_this, p0, p1) => _this.set(p0, p1),
    'androidx.compose.ui.internal.get_$external_fun' : (_this, p0) => _this.get(p0),
    'androidx.compose.ui.platform.createClipboardItemWithPlainText' : (text) => [new ClipboardItem({'text/plain': new Blob([text], { type: 'text/plain' })})],
    'androidx.compose.ui.platform.emptyClipboardItems' : () => [new ClipboardItem({'text/plain': new Blob([''], { type: 'text/plain' })})],
    'androidx.compose.ui.platform.invalidClipboardItems' : () => [],
    'androidx.compose.ui.platform.warn' : (text) => { console.warn(text) },
    'androidx.compose.ui.events.withSignal' : (signal) => ({signal: signal}),
    'androidx.compose.ui.events.withSignalAndPassive' : (signal, passive) => ({signal: signal, passive: passive}),
    'androidx.compose.ui.events.AbortController_$external_fun' : () => new AbortController(),
    'androidx.compose.ui.events.signal_$external_prop_getter' : (_this) => _this.signal,
    'androidx.compose.ui.events.abort_$external_fun' : (_this, ) => _this.abort(),
    'androidx.compose.ui.internal.focusExt' : (element, _preventScroll) => element.focus({ preventScroll: _preventScroll }),
    'androidx.compose.ui.node.WeakRef_$external_fun' : (p0) => new WeakRef(p0),
    'androidx.compose.ui.node.deref_$external_fun' : (_this, ) => _this.deref(),
    'androidx.compose.ui.platform.setBackingInputBox' : (container, left, top, width, height) => { 
        container.style.setProperty("--compose-internal-web-backing-input-left", left);
        container.style.setProperty("--compose-internal-web-backing-input-top", top);
        container.style.setProperty("--compose-internal-web-backing-input-width", width);
        container.style.setProperty("--compose-internal-web-backing-input-height", height)
     },
    'androidx.compose.ui.platform.isVibrationSupported' : () => 
            typeof window !== 'undefined' &&
            window.navigator != null &&
            typeof window.navigator.vibrate === 'function'
        ,
    'androidx.compose.ui.platform.vibrate' : (pattern) => { window.navigator.vibrate(pattern) },
    'androidx.compose.ui.platform.getSelectionRange' : (element) => {
            var selection = window.getSelection();
            if (selection == null) return null;
            var root = element.getRootNode();
            if (root == null) return null;

            if (typeof selection.getComposedRanges === 'function') {
                try {
                    // The modern standard approach
                    var composedRanges = selection.getComposedRanges({ shadowRoots: [root] });
                    if (composedRanges.length > 0) {
                        return composedRanges[0];
                    }
                    return null;
                } catch (e) {
                    // Fallback for early Safari 17 point-releases
                    var composedRanges = selection.getComposedRanges(root);
                    if (composedRanges.length > 0) {
                        return composedRanges[0];
                    }
                    return null;
                }
            }

            if (typeof root.getSelection === 'function') {
                var rootSelection = root.getSelection();
                if (rootSelection == null) return [0, 0];
                if (rootSelection.rangeCount > 0) {
                    return rootSelection.getRangeAt(0);
                }
                return null;
            }

            if (selection.rangeCount > 0) {
                return selection.getRangeAt(0);
            }
            return null;
        },
    'androidx.compose.ui.platform.computeSelectionOffset' : (container, offset) => {          
        // container.nodeType stands for textNodes                   
        if (container.nodeType == 3) return offset;
        var chars = 0;
        var n = Math.min(offset, container.childNodes.length);
        for (var i = 0; i < n; i++) {
            var c = container.childNodes[i];
            chars += (c.nodeType == 3)
                ? c.nodeValue.length
                : ((c.textContent && c.textContent.length) || 0);
        }
        return chars;
        },
    'androidx.compose.ui.platform.isTypedEvent' : (evt) => !evt.metaKey && !evt.ctrlKey && evt.key.charAt(0) === evt.key,
    'androidx.compose.ui.platform.data_$external_prop_getter' : (_this) => _this.data,
    'androidx.compose.ui.platform.inputType_$external_prop_getter' : (_this) => _this.inputType,
    'androidx.compose.ui.platform.firstRange_$external_prop_getter' : (_this) => _this.firstRange,
    'androidx.compose.ui.platform.firstRange_$external_prop_setter' : (_this, v) => _this.firstRange = v,
    'androidx.compose.ui.platform.getTargetRanges_$external_fun' : (_this, ) => _this.getTargetRanges(),
    'androidx.compose.ui.platform.startContainer_$external_prop_getter' : (_this) => _this.startContainer,
    'androidx.compose.ui.platform.startOffset_$external_prop_getter' : (_this) => _this.startOffset,
    'androidx.compose.ui.platform.endContainer_$external_prop_getter' : (_this) => _this.endContainer,
    'androidx.compose.ui.platform.endOffset_$external_prop_getter' : (_this) => _this.endOffset,
    'androidx.compose.ui.platform.collapsed_$external_prop_getter' : (_this) => _this.collapsed,
    'androidx.compose.ui.platform.activeElement_$external_prop_getter' : (_this) => _this.activeElement,
    'androidx.compose.ui.platform.getRootNode_$external_fun' : (_this, ) => _this.getRootNode(),
    'androidx.compose.ui.platform.setBaseAndExtent_$external_fun' : (_this, p0, p1, p2, p3) => _this.setBaseAndExtent(p0, p1, p2, p3),
    'androidx.compose.ui.platform.getSelection_$external_fun' : (_this, ) => _this.getSelection(),
    'androidx.compose.ui.platform.getW3CClipboard' : () => window.navigator.clipboard,
    'androidx.compose.ui.platform.isSecureContext' : () => window.isSecureContext === true,
    'androidx.compose.ui.platform.isFullClipboardApiSupported' : () => Boolean(
            window.navigator.clipboard && 
            window.navigator.clipboard.write && 
            window.navigator.clipboard.read && 
            typeof(ClipboardItem) !== 'undefined'
            )
        ,
    'androidx.compose.ui.platform.isFallbackWriteTextApiAvailable' : () => Boolean(window.navigator.clipboard && window.navigator.clipboard.writeText),
    'androidx.compose.ui.platform.read_$external_fun' : (_this, ) => _this.read(),
    'androidx.compose.ui.platform.write_$external_fun' : (_this, p0) => _this.write(p0),
    'androidx.compose.ui.platform.writeText_$external_fun' : (_this, p0) => _this.writeText(p0),
    'androidx.compose.ui.platform.W3CTemporaryClipboard_$external_class_instanceof' : (x) => x instanceof Clipboard,
    'androidx.compose.ui.platform.W3CTemporaryClipboard_$external_class_get' : () => Clipboard,
    'androidx.compose.ui.platform.types_$external_prop_getter' : (_this) => _this.types,
    'androidx.compose.ui.platform.getType_$external_fun' : (_this, p0) => _this.getType(p0),
    'androidx.compose.ui.platform.isSchedulerApiSupported' : () => Boolean('scheduler' in window),
    'androidx.compose.ui.platform.schedulerPostTask' : (block) => scheduler.postTask(block, { priority: 'user-blocking',}),
    'androidx.compose.ui.platform.isIdleApiSupported' : () => Boolean('requestIdleCallback' in window),
    'androidx.compose.ui.platform.requestIdleCallback' : (callback) => window.requestIdleCallback(callback),
    'androidx.compose.ui.platform.cancelIdleCallback' : (handle) => { window.cancelIdleCallback(handle) },
    'androidx.compose.ui.platform.timeRemaining_$external_fun' : (_this, ) => _this.timeRemaining(),
    'androidx.compose.ui.platform.didTimeout_$external_prop_getter' : (_this) => _this.didTimeout,
    'androidx.compose.ui.platform.isFullWakeLockApiSupported' : () => Boolean(
            window.navigator.wakeLock && 
            typeof(WakeLockSentinel) !== 'undefined'
            )
        ,
    'androidx.compose.ui.platform.hasVirtualKeyboard' : () => ('virtualKeyboard' in navigator),
    'androidx.compose.ui.platform.installSafeAreaCssProperties' : () => (function() {
            let s = document.documentElement.style;
            s.setProperty('--cmp-safe-top', 'env(safe-area-inset-top, 0px)');
            s.setProperty('--cmp-safe-right', 'env(safe-area-inset-right, 0px)');
            s.setProperty('--cmp-safe-bottom', 'env(safe-area-inset-bottom, 0px)');
            s.setProperty('--cmp-safe-left', 'env(safe-area-inset-left, 0px)');
        })(),
    'androidx.compose.ui.platform.enableVirtualKeyboardOverlay' : () => (navigator.virtualKeyboard.overlaysContent = true),
    'androidx.compose.ui.platform.getVirtualKeyboard' : () => navigator.virtualKeyboard,
    'androidx.compose.ui.platform.getVisualViewport' : () => (window.visualViewport || null),
    'androidx.compose.ui.platform.readCssVarLeft' : () => (parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--cmp-safe-left')) || 0),
    'androidx.compose.ui.platform.readCssVarTop' : () => (parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--cmp-safe-top')) || 0),
    'androidx.compose.ui.platform.readCssVarRight' : () => (parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--cmp-safe-right')) || 0),
    'androidx.compose.ui.platform.readCssVarBottom' : () => (parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--cmp-safe-bottom')) || 0),
    'androidx.compose.ui.platform.readVirtualKeyboardHeight' : () => (navigator.virtualKeyboard.boundingRect.height || 0),
    'androidx.compose.ui.platform.readVisualViewportImeHeight' : () => (function() {
        let vv = window.visualViewport;
        if (!vv) return 0;
        return Math.max(0, window.innerHeight - vv.height - vv.offsetTop);
    })(),
    'androidx.compose.ui.platform.accessibility.setA11YAriaRole' : (element, ariaRoleId) => { 
            var roleValue = "";
            switch (ariaRoleId) {
                case 0: // Role.Button
                    roleValue = "button";
                    break;
                case 1: // Role.Checkbox
                    roleValue = "checkbox";
                    break;
                case 2: // Role.Switch
                    roleValue = "switch";
                    break;
                case 3: // Role.RadioButton
                    roleValue = "radio";
                    break;
                case 4: // Role.Tab
                    roleValue = "tab";
                    break;
                case 5: // Role.Image
                    roleValue = "img";
                    break;
                case 6: // Role.DropdownList
                    roleValue = "menu";
                    break;
                case 7: // heading https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Roles/heading_role
                    roleValue = "heading";
                    break;
                case 8: // https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Roles/textbox_role
                    roleValue = "textbox";
                    break;
                case 9: // https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Roles/list_role
                    roleValue = "list";
                    break;
                case 10: // https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Roles/grid_role
                    roleValue = "grid";
                    break;
                case 11: // https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Roles/dialog_role
                    roleValue = "dialog";
                    break;
                case 12: // https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Roles/link_role
                    roleValue = "link";
                    break;
                default:
                    break;
            }
            if (roleValue.length > 0) { 
                element.setAttribute("role", roleValue);
            } else {
                element.removeAttribute("role");
            }
         },
    'androidx.compose.ui.platform.accessibility.setSizeAndPosition' : (element, left, top, width, height) => { 
           element.style.left = "" + left + "px";
           element.style.top = "" + top + "px";
           element.style.width = "" + width + "px";
           element.style.height = "" + height + "px";
         },
    'androidx.compose.ui.platform.accessibility.removeAllChildrenOf' : (element) => { element.replaceChildren() },
    'androidx.compose.ui.platform.accessibility.toggleAttribute_$external_fun' : (_this, p0, p1) => _this.toggleAttribute(p0, p1),
    'androidx.compose.ui.window.clearNodeChildren' : (node) => 
            {
                if (node.hasChildNodes()) node.replaceChildren();
            }
        ,
    'androidx.compose.ui.window.isWebGL2Supported' : () => !!document.createElement('canvas').getContext('webgl2'),
    'androidx.compose.ui.window.documentIsVisible' : () => document.visibilityState === 'visible',
    'androidx.compose.ui.window.checkViewportFitCover' : () => (function() {
            let meta = document.querySelector('meta[name=viewport]');
            let content = meta ? (meta.getAttribute('content') || '') : '';
            if (!content.includes('viewport-fit=cover')) {
                console.warn(
                    "[ComposeWeb] enableBrowserWindowInsets is set to true, but " +
                    "'viewport-fit=cover' is not found in the viewport meta tag. " +
                    "Safe area insets will be zero. Add viewport-fit=cover to your viewport meta tag: " +
                    "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">"
                );
            }
        })(),
    'androidx.compose.ui.window.getVisualViewportScale' : () => window.visualViewport.scale,
    'androidx.compose.ui.window.isTouchEvent' : (event) => event.pointerType === 'touch',
    'androidx.compose.ui.window.releasePointerCapture' : (target, pointerId) => { try { target.releasePointerCapture(pointerId) } catch (e) {} },
    'androidx.compose.ui.window.isMouseEvent' : (event) => event.pointerType === 'mouse',
    'androidx.compose.ui.window.setPointerCapture' : (target, pointerId) => { try { target.setPointerCapture(pointerId) } catch (e) {} },
    'androidx.compose.ui.window.getCoalescedEvents' : (pointerEvent) => pointerEvent.getCoalescedEvents ? pointerEvent.getCoalescedEvents() : [],
    'androidx.compose.ui.window.composeComponentElementCtor' : (weakMap) => 
        (() => {
            class ComposeComponentElement extends HTMLElement {
                disconnectedCallback() {
                    const cb = weakMap.get(this);
                    if (cb) cb();
                }
            }
            return ComposeComponentElement;
        })()
    ,
    'androidx.compose.ui.window.clientXOf' : (event) => event.clientX,
    'androidx.compose.ui.window.clientYOf' : (event) => event.clientY,
    'androidx.compose.ui.window.getPointerEventCode' : (event) => {
            switch (event.type) {
              case 'pointerdown':
                return 1; // PointerEventType.Press
              case 'pointerup':
                return 2; // PointerEventType.Release
              case 'pointermove':
                return 3; // PointerEventType.Move
              case 'pointerenter':
                return 4; //PointerEventType.Enter
              case 'pointerleave':
                return 5; //PointerEventType.Exit
              default:
                return 0; // PointerEventType.Unknown
            } 
        },
    'androidx.compose.ui.window.getVisualViewport' : () => window.visualViewport,
    'androidx.compose.ui.window.activeElement_$external_prop_getter' : (_this) => _this.activeElement,
    'androidx.compose.ui.window.WeakMap_$external_fun' : () => new WeakMap(),
    'androidx.compose.ui.window.set_$external_fun' : (_this, p0, p1) => _this.set(p0, p1),
    'androidx.compose.ui.window.delete_$external_fun' : (_this, p0) => _this.delete(p0),
    'androidx.compose.ui.window.get_$external_fun' : (_this, p0) => _this.get(p0),
    'androidx.compose.ui.window.define_$external_fun' : (_this, p0, p1) => _this.define(p0, p1),
    'androidx.compose.ui.window.customElements_$external_prop_getter' : () => customElements,
    'androidx.compose.ui.window.isMatchMediaSupported' : () => window.matchMedia != undefined,
    'ee.schimke.composeai.uibuilder.renderer.sdk.runtimeIdFromPath' : () => {
        const parts = globalThis.location.pathname.split('/').filter(Boolean);
        const marker = parts.lastIndexOf('runtime');
        const runtimeId = marker >= 0 ? parts[marker + 1] : '';
        if (!runtimeId || !/^[A-Za-z0-9._-]+$/.test(runtimeId) || runtimeId === 'latest' || runtimeId === 'current') {
          throw new Error('renderer must be loaded from an exact /ui-builder/runtime/<runtimeId>/ path');
        }
        return runtimeId;
      },
    'ee.schimke.composeai.uibuilder.renderer.sdk.installRuntimeReceiver' : (handler) => (function () {
          globalThis.addEventListener('message', function (event) {
            if (event.source !== globalThis.parent || typeof event.data !== 'string') return;
            if (globalThis.__uiBuilderParentOrigin && event.origin !== globalThis.__uiBuilderParentOrigin) return;
            if (!globalThis.__uiBuilderParentOrigin) globalThis.__uiBuilderParentOrigin = event.origin;
            handler(event.origin, event.data);
          });
        })(),
    'ee.schimke.composeai.uibuilder.renderer.sdk.__convertKotlinClosureToJsClosure_2' : (f, trampoline) => getCachedJsObject(f, (p0, p1) => trampoline(f, p0, p1)),
    'ee.schimke.composeai.uibuilder.renderer.sdk.postRuntimeMessage' : (encoded) => globalThis.parent.postMessage(encoded, globalThis.__uiBuilderParentOrigin),
    'ee.schimke.composeai.uibuilder.renderer.sdk.scheduleRuntimeViewport' : (callback) => setTimeout(callback, 0),
    'ee.schimke.composeai.uibuilder.renderer.sdk.scheduleActionCompletion' : (callback) => requestAnimationFrame(function () {
          requestAnimationFrame(function () { requestAnimationFrame(callback); });
        }),
    'ee.schimke.composeai.uibuilder.renderer.sdk.scheduleMeasuredResponse' : (delayMs, callback) => (function () {
          const token = (globalThis.__uiBuilderMeasureToken || 0) + 1;
          globalThis.__uiBuilderMeasureToken = token;
          // Opaque sandbox frames can have requestAnimationFrame suspended while offscreen or behind
          // another editor surface. A short cancellable settle window still coalesces layout snapshots
          // without tying protocol completion to browser visibility.
          setTimeout(function () {
            if (globalThis.__uiBuilderMeasureToken !== token) return;
            callback();
          }, delayMs);
        })(),
    'ee.schimke.composeai.uibuilder.renderer.sdk.markRendererReady' : () => document.documentElement.dataset.uiBuilderRendererReady = 'true',
    'androidx.compose.foundation.internal.isClipboardWriteSupported' : () => Boolean(window.navigator.clipboard && (window.navigator.clipboard.write || window.navigator.clipboard.writeText)),
    'androidx.compose.foundation.internal.isClipboardReadSupported' : () => Boolean(window.navigator.clipboard && window.navigator.clipboard.read),
    'androidx.compose.foundation.internal.getTextFromBlob' : (blob) => blob.text(),
    'androidx.compose.foundation.internal.doesJsArrayContainValue' : (jsArray, value) => jsArray.includes(value),
    'androidx.compose.foundation.text.EventListener' : (handler) => (event) => { handler(event) },
    'androidx.compose.foundation.gestures.legacyWheelDeltaX' : (event) => (event.wheelDeltaX == null) ? NaN : event.wheelDeltaX,
    'androidx.compose.foundation.gestures.legacyWheelDeltaY' : (event) => (event.wheelDeltaY == null) ? NaN : event.wheelDeltaY,
    'ee.schimke.a2uicmp.port.dateNow' : () => Date.now(),
    'kotlinx.datetime.internal.Date_$external_fun' : (p0) => new Date(p0),
    'kotlinx.datetime.internal.getTimezoneOffset_$external_fun' : (_this, ) => _this.getTimezoneOffset(),
    'kotlinx.datetime.internal.JSJoda.ZoneRulesProvider_$external_object_getInstance' : () => _ref_QGpzLWpvZGEvY29yZQ_.ZoneRulesProvider,
    'kotlinx.datetime.internal.JSJoda.id_$external_fun' : (_this, ) => _this.id(),
    'kotlinx.datetime.internal.JSJoda.systemDefault_$external_fun' : (_this, ) => _this.systemDefault(),
    'kotlinx.datetime.internal.JSJoda.Companion_$external_object_getInstance' : () => _ref_QGpzLWpvZGEvY29yZQ_.ZoneId,
    'kotlinx.datetime.internal.withCaughtJsException' : (body) => {
        try {
            body();
            return null;
        } catch(e) {
            return e;
        }
    },
    'kotlinx.datetime.internal.getExceptionMessage' : (jsException) => jsException.message,
    'kotlinx.datetime.internal.getZones' : (rulesProvider) => rulesProvider.getTzdbData().zones,
    'kotlinx.datetime.internal.getLinks' : (rulesProvider) => rulesProvider.getTzdbData().links,
    'androidx.compose.material3.internal.weakMap_js_code' : () => (new WeakMap()),
    'androidx.compose.material3.internal.set_$external_fun' : (_this, p0, p1) => _this.set(p0, p1),
    'androidx.compose.material3.internal.get_$external_fun' : (_this, p0) => _this.get(p0),
    'androidx.compose.material3.internal.getFirstDayOfWeek' : (locale) => { try { 
               return new Intl.Locale(locale).weekInfo.firstDay; 
            } catch (error) { 
               return -1; 
          }},
    'androidx.compose.material3.internal.getIs24HourFormat' : (localeTag) => {
                var locale = new Intl.Locale(localeTag);
                // Check for the hourCycles property first
                if (locale.hourCycles) {
                    return locale.hourCycles.includes('h23') || locale.hourCycles.includes('h24') ? 1 : 0;
                }

                // Fallback to hourCycle property
                if (locale.hourCycle) {
                    return locale.hourCycle === 'h23' || locale.hourCycle === 'h24' ? 1 : 0;
                }
                return -1;
            },
    'androidx.compose.material3.internal.emptyLocaleOptions' : () => new Object(),
    'androidx.compose.material3.internal.Date_$external_fun' : (p0) => new Date(p0),
    'androidx.compose.material3.internal.Date_$external_fun_1' : (p0, p1, p2) => new Date(p0, p1, p2),
    'androidx.compose.material3.internal.getDay_$external_fun' : (_this, ) => _this.getDay(),
    'androidx.compose.material3.internal.toLocaleDateString_$external_fun' : (_this, p0, p1, isDefault0) => _this.toLocaleDateString(p0, isDefault0 ? undefined : p1, ),
    'androidx.compose.material3.internal.now_$external_fun' : (_this, ) => _this.now(),
    'androidx.compose.material3.internal.Companion_$external_object_getInstance' : () => Date,
    'androidx.compose.material3.internal.weekday_$external_prop_setter' : (_this, v) => _this.weekday = v,
    'androidx.compose.material3.internal.year_$external_prop_setter' : (_this, v) => _this.year = v,
    'androidx.compose.material3.internal.month_$external_prop_setter' : (_this, v) => _this.month = v,
    'androidx.compose.material3.internal.day_$external_prop_setter' : (_this, v) => _this.day = v,
    'androidx.compose.material3.internal.hour_$external_prop_setter' : (_this, v) => _this.hour = v,
    'androidx.compose.material3.internal.minute_$external_prop_setter' : (_this, v) => _this.minute = v,
    'androidx.compose.material3.internal.second_$external_prop_setter' : (_this, v) => _this.second = v,
    'androidx.compose.material3.internal.Date_$external_class_instanceof' : (x) => x instanceof Date,
    'androidx.compose.material3.internal.Date_$external_class_get' : () => Date,
    'ee.schimke.a2uicatalog.uibuilder.fetchFonts' : (onLoaded, onFailed) => {
        const load = (file) => fetch('fonts/' + file).then((response) => {
          if (!response.ok) throw new Error(file + ': HTTP ' + response.status);
          return response.arrayBuffer();
        }).then((buffer) => new Int8Array(buffer));
        Promise.all([load('Roboto-Regular.ttf'), load('Roboto-Medium.ttf')])
          .then(([regular, medium]) => onLoaded(regular, medium), (error) => onFailed(String(error)));
      },
    'ee.schimke.a2uicatalog.uibuilder.byteLength' : (array) => array.length,
    'ee.schimke.a2uicatalog.uibuilder.byteAt' : (array, index) => array[index]
}

const StringConstantsProxy = new Proxy({}, {
  get(_, prop) { return prop; }
});

export { wasmTag as __TAG };

export const importObject = {
    js_code,
    intrinsics: {
        memory: new WebAssembly.Memory({ initial: 0 }),
        tag: wasmTag
    },
    "'": StringConstantsProxy,
    'wasm:js-string': d2FzbTpqcy1zdHJpbmc,
    './skiko.mjs': Li9za2lrby5tanM,
};
    